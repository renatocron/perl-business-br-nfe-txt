perl-business-br-nfe-txt
========================

Gera NFE em formato TXT layout 1 documentado em http://nfpaulistana.prefeitura.sp.gov.br/arquivos/manual/NFe_Layout_RPS.pdf